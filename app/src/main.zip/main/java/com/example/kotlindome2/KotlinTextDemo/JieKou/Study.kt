package com.example.kotlindome2.KotlinTextDemo.JieKou

interface Study{
    fun readBooks(){
        println("当前的接口打印数据")
    }
    fun doHomework()
}