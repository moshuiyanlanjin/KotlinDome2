package com.example.kotlindome2.Activity

import android.os.Bundle

class FragActivity : BaseActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

}
